# Shamanth R — Cybersecurity Portfolio

## Run locally

```bash
npm install
npm run dev
```

## Build for GitHub Pages

```bash
npm install
npm run build
```

Then upload the contents of the `dist/` folder to your GitHub Pages repository,
or push the entire repo and enable GitHub Pages to serve from the `dist/` folder.

## Deploy to GitHub Pages (one-time setup)

1. Push this folder to a GitHub repo
2. Go to Settings → Pages
3. Set Source to **GitHub Actions** and use the workflow below,
   OR set Source to **Deploy from branch → main → /dist** after running `npm run build` locally
   and committing the `dist/` folder.

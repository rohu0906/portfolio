import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Target, Activity, Brain } from "lucide-react";

const pillars = [
  {
    icon: Target,
    label: "01",
    title: "Offensive Security",
    body: "Full-scope penetration testing across Web Apps, Networks, and OS. Compromised 20+ real-world machines using Metasploit, Burp Suite, and custom AI-assisted scripts.",
    color: "#a855f7",
  },
  {
    icon: Activity,
    label: "02",
    title: "Threat Operations",
    body: "Active threat hunting and incident response with QRadar and Splunk. Malware assessment, EDR/XDR triage, and live forensics across enterprise environments.",
    color: "#22d3ee",
  },
  {
    icon: Brain,
    label: "03",
    title: "AI-Driven Security",
    body: "Automating vulnerability assessment pipelines with OSINT + GenAI. Building custom CTF challenges and security training programs for college-level audiences.",
    color: "#a855f7",
  },
];

export default function About() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="about" ref={ref} data-testid="about-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="mb-14"
      >
        <p className="section-label">&gt; whoami</p>
        <h2 className="text-4xl md:text-5xl font-extrabold" style={{ fontFamily: "var(--font-display)" }}>
          About<span className="text-gradient">.</span>
        </h2>
      </motion.div>

      <div className="grid lg:grid-cols-5 gap-10 items-start">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <div className="relative p-6 rounded-2xl bg-white/3 border border-white/5 overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 orb-purple rounded-full blur-2xl pointer-events-none" />
            <p className="text-lg text-foreground/90 leading-relaxed mb-5 relative z-10">
              I break systems for a living —{" "}
              <span className="text-gradient font-semibold">legally.</span>
            </p>
            <p className="text-muted-foreground leading-relaxed text-sm relative z-10">
              2 years of hands-on blended experience spanning Offensive Security and Security Operations.
              Proficient in full-scope pen testing, SIEM/XDR-based threat hunting, and automating security
              workflows with AI and OSINT — with real-world impact, not just lab practice.
            </p>
            <div className="mt-6 pt-5 border-t border-white/5 relative z-10">
              <div className="font-mono text-xs text-muted-foreground/60 mb-2">Currently studying at</div>
              <div className="font-semibold text-sm text-foreground">IIT Roorkee</div>
              <div className="text-xs text-primary/80 font-mono">PG — AI/GenAI Powered Cybersecurity</div>
            </div>
          </div>
        </motion.div>

        <div className="lg:col-span-3 flex flex-col gap-4">
          {pillars.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, x: 30 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.15 + i * 0.12 }}
              data-testid={`highlight-${p.title.toLowerCase().replace(/\s+/g, "-")}`}
              className="group relative flex gap-5 p-5 rounded-xl bg-white/3 border border-white/5 hover:border-primary/25 transition-all duration-300 overflow-hidden"
            >
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: `radial-gradient(ellipse at top left, ${p.color}08 0%, transparent 60%)` }}
              />
              <div className="shrink-0 flex flex-col items-center gap-2">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ background: `${p.color}15`, color: p.color }}
                >
                  <p.icon size={18} />
                </div>
                <span className="font-mono text-xs text-muted-foreground/40">{p.label}</span>
              </div>
              <div className="relative z-10">
                <h3 className="font-bold text-foreground mb-1.5" style={{ fontFamily: "var(--font-display)" }}>
                  {p.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{p.body}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Mail, Linkedin, FileDown } from "lucide-react";

const TERMINAL_LINES = [
  { delay: 0, text: "$ sudo nmap -sV -O --script vuln 192.168.1.0/24", color: "text-muted-foreground" },
  { delay: 800, text: "Starting Nmap 7.94 ( https://nmap.org )", color: "text-muted-foreground/60" },
  { delay: 1400, text: "Scanning 256 hosts...", color: "text-muted-foreground/60" },
  { delay: 2200, text: "Host: 192.168.1.42 — VULNERABLE", color: "text-red-400" },
  { delay: 3000, text: "CVE-2024-21413 | CVSS: 9.8 CRITICAL", color: "text-orange-400" },
  { delay: 3800, text: "$ msfconsole -q -x 'use exploit/...'", color: "text-muted-foreground" },
  { delay: 4600, text: "[*] Session 1 opened — shell spawned", color: "text-green-400" },
  { delay: 5400, text: "whoami > root", color: "#a855f7" },
];

function TerminalWindow() {
  const [visibleLines, setVisibleLines] = useState<number>(0);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    TERMINAL_LINES.forEach((_, i) => {
      const t = setTimeout(() => {
        setVisibleLines(i + 1);
      }, TERMINAL_LINES[i].delay + 600);
      timers.push(t);
    });
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="relative rounded-xl overflow-hidden bg-black/60 backdrop-blur-sm border border-white/10"
      style={{ boxShadow: "0 0 60px hsl(270 91% 65% / 0.12), inset 0 1px 0 rgba(255,255,255,0.06)" }}
    >
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-white/3">
        <div className="w-3 h-3 rounded-full bg-red-500/70" />
        <div className="w-3 h-3 rounded-full bg-yellow-500/70" />
        <div className="w-3 h-3 rounded-full bg-green-500/70" />
        <span className="ml-3 font-mono text-xs text-muted-foreground/50">terminal — shamanth@kali</span>
      </div>
      <div className="p-4 font-mono text-xs leading-relaxed min-h-[180px]">
        {TERMINAL_LINES.slice(0, visibleLines).map((line, i) => (
          <div
            key={i}
            className="mb-1"
            style={typeof line.color === "string" && line.color.startsWith("#")
              ? { color: line.color }
              : undefined}
          >
            <span className={typeof line.color === "string" && !line.color.startsWith("#") ? line.color : ""}>{line.text}</span>
            {i === visibleLines - 1 && (
              <span className="inline-block w-2 h-3.5 bg-primary ml-0.5 align-middle animate-pulse" />
            )}
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function CountUp({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const duration = 1500;
    const steps = 40;
    const increment = target / steps;
    let current = 0;
    ref.current = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        if (ref.current) clearInterval(ref.current);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);
    return () => { if (ref.current) clearInterval(ref.current); };
  }, [target]);

  return <>{count}{suffix}</>;
}

const stats = [
  { value: 20, suffix: "+", label: "Machines Compromised" },
  { value: 2, suffix: "+", label: "Years Experience" },
  { value: 5, suffix: "", label: "Certifications" },
  { value: 3, suffix: "", label: "Workshops" },
];

export default function Hero() {
  return (
    <section
      data-testid="hero-section"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      <div className="absolute inset-0 bg-background" />
      <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] orb-purple rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] orb-cyan rounded-full blur-3xl pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(168,85,247,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.03)_1px,transparent_1px)] bg-[size:60px_60px] pointer-events-none" />

      <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-12 w-full pt-24 pb-20">

        {/* Full-width name row */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex items-center gap-3 mb-5"
        >
          <div className="h-px w-8 bg-primary" />
          <span className="font-mono text-xs tracking-[0.25em] text-primary uppercase">
            Cybersecurity Professional
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="text-[clamp(2.2rem,6vw,5rem)] font-extrabold leading-[0.88] tracking-tight mb-10"
          style={{ fontFamily: "var(--font-display)" }}
        >
          <span className="block text-foreground">SHAMANTH</span>
          <span className="block text-gradient">R.</span>
        </motion.h1>

        {/* Two-column row below the name */}
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="flex flex-wrap gap-2 mb-6"
            >
              {["Ethical Hacker", "Pen Tester", "SecOps", "AI Security"].map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 rounded-full font-mono text-xs border border-primary/30 text-primary/80 bg-primary/5"
                >
                  {tag}
                </span>
              ))}
            </motion.div>

            <motion.p
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.5 }}
              className="text-muted-foreground text-base leading-relaxed mb-8 max-w-md"
            >
              2+ years compromising real systems through full-scope penetration testing,
              AI-driven vulnerability automation, and active threat hunting.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.65 }}
              className="flex flex-wrap gap-3 mb-10"
            >
              <a
                href="mailto:Shamantrsingh@gmail.com"
                data-testid="hero-email"
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground font-mono text-sm font-medium hover:opacity-90 transition-opacity glow-purple"
              >
                <Mail size={15} /> Email Me
              </a>
              <a
                href="https://linkedin.com/in/shamanth-r-2h0c2ooc"
                target="_blank"
                rel="noopener noreferrer"
                data-testid="hero-linkedin"
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg border border-primary/30 text-primary font-mono text-sm hover:bg-primary/10 transition-all"
              >
                <Linkedin size={15} /> LinkedIn <ArrowRight size={13} />
              </a>
              <a
                href="/resume.pdf"
                download="Shamanth_R_Resume.pdf"
                data-testid="hero-resume"
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg border border-accent/30 text-accent font-mono text-sm hover:bg-accent/10 transition-all"
              >
                <FileDown size={15} /> Resume
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="grid grid-cols-2 sm:grid-cols-4 gap-4"
            >
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.85 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.85 + i * 0.08 }}
                  data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className="rounded-xl p-4 bg-white/3 border border-white/5 hover:border-primary/20 transition-colors text-center"
                >
                  <div className="text-2xl font-bold font-mono text-gradient mb-1">
                    <CountUp target={stat.value} suffix={stat.suffix} />
                  </div>
                  <div className="text-xs text-muted-foreground leading-tight">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          <div className="hidden lg:flex flex-col gap-4">
            <TerminalWindow />

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.2 }}
              className="p-4 rounded-xl bg-white/3 border border-white/5 font-mono text-xs"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-muted-foreground">status.json</span>
              </div>
              <div className="space-y-1 text-muted-foreground/70">
                <div><span className="text-primary/80">"location"</span>: <span className="text-green-400/80">"Bengaluru, IN"</span></div>
                <div><span className="text-primary/80">"status"</span>: <span className="text-green-400">"open_to_work"</span></div>
                <div><span className="text-primary/80">"phone"</span>: <span className="text-accent/80">"+91 9620215143"</span></div>
                <div><span className="text-primary/80">"education"</span>: <span className="text-yellow-400/80">"IIT Roorkee (in progress)"</span></div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

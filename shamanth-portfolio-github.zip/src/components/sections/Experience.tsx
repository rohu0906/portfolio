import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";

const experiences = [
  {
    index: "01",
    role: "Cyber Security Analyst",
    badge: "Current",
    badgeColor: "#22d3ee",
    company: "Thincnext",
    period: "Jun 2025 – Present",
    location: "Bengaluru",
    bullets: [
      "Compromised target website and gained full administrator access",
      "Automated vulnerability assessment pipelines using OSINT tools and AI/ML techniques",
      "Designed syllabus and complete structure for cybersecurity workshops",
      "Built custom Capture The Flag (CTF) challenges based on real-world hacking scenarios",
    ],
  },
  {
    index: "02",
    role: "Cyber Security Professional",
    badge: "Internship",
    badgeColor: "#a855f7",
    company: "Hacker School (Cartel Software Pvt. Ltd.)",
    period: "Jan 2025 – Jun 2025",
    location: "Bengaluru",
    bullets: [
      "Full-scope hands-on Penetration Testing across Web Apps, Networks, and Operating Systems",
      "Compromised 20+ machines, websites, and networks using AI-assisted exploitation techniques",
      "Gained expertise in Network Security, Wireless Hacking, and securing IoT ecosystems",
      "SecOps and Threat Hunting using SIEM/XDR (QRadar, Splunk) — Incident Response + Malware Assessment",
    ],
  },
  {
    index: "03",
    role: "SOC Analyst Training",
    badge: "Training",
    badgeColor: "#a855f7",
    company: "Ashtaksha Lab",
    period: "Dec 2024 – Apr 2025",
    location: "Bengaluru",
    bullets: [
      "Kali Linux offensive security, Cyber Kill Chain, SIEM (Splunk), IDS/IPS/EDR/XDR threat analysis",
      "Cryptography & Data Security — DLP, PII/PHI, Steganography, Symmetric/Asymmetric encryption",
      "Network Architecture — OSI/TCP-IP, Firewall/VPN deployment, VLAN segmentation, Wireshark analysis",
    ],
  },
];

function ExperienceCard({ exp, index, inView }: { exp: typeof experiences[0]; index: number; inView: boolean }) {
  const [open, setOpen] = useState(index === 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      data-testid={`experience-${index}`}
      className="relative group"
    >
      <div
        className={`rounded-2xl border transition-all duration-300 overflow-hidden cursor-pointer ${
          open
            ? "border-primary/30 bg-white/4"
            : "border-white/5 bg-white/2 hover:border-white/10"
        }`}
        onClick={() => setOpen((v) => !v)}
      >
        <div className="p-5 md:p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <span
                className="font-mono text-xs font-bold mt-1"
                style={{ color: exp.badgeColor, opacity: 0.7 }}
              >
                [{exp.index}]
              </span>
              <div>
                <div className="flex items-center gap-3 flex-wrap mb-1">
                  <h3
                    className="text-lg font-bold text-foreground"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {exp.role}
                  </h3>
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-mono"
                    style={{ background: `${exp.badgeColor}15`, color: exp.badgeColor }}
                  >
                    {exp.badge}
                  </span>
                </div>
                <div className="text-sm text-muted-foreground font-mono">
                  {exp.company}
                </div>
                <div className="flex gap-3 mt-1 font-mono text-xs text-muted-foreground/50">
                  <span>{exp.period}</span>
                  <span>·</span>
                  <span>{exp.location}</span>
                </div>
              </div>
            </div>
            <motion.div
              animate={{ rotate: open ? 180 : 0 }}
              transition={{ duration: 0.3 }}
              className="shrink-0 mt-1"
            >
              <ChevronDown size={16} className="text-muted-foreground" />
            </motion.div>
          </div>
        </div>

        <AnimatePresence initial={false}>
          {open && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="px-5 md:px-6 pb-5 md:pb-6 border-t border-white/5">
                <ul className="mt-4 space-y-3">
                  {exp.bullets.map((b, j) => (
                    <li key={j} className="flex items-start gap-3 text-sm text-muted-foreground">
                      <span
                        className="mt-1.5 w-1.5 h-1.5 rounded-full shrink-0"
                        style={{ background: exp.badgeColor }}
                      />
                      {b}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default function Experience() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="experience" ref={ref} data-testid="experience-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="mb-14"
      >
        <p className="section-label">&gt; cat experience.log</p>
        <h2 className="text-4xl md:text-5xl font-extrabold" style={{ fontFamily: "var(--font-display)" }}>
          Experience<span className="text-gradient">.</span>
        </h2>
      </motion.div>

      <div className="flex flex-col gap-4">
        {experiences.map((exp, i) => (
          <ExperienceCard key={exp.company} exp={exp} index={i} inView={inView} />
        ))}
      </div>
    </section>
  );
}

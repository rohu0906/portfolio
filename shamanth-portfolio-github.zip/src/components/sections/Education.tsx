import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const education = [
  {
    degree: "PG Certificate — AI/GenAI Powered Cybersecurity",
    institution: "IIT Roorkee × Futurense",
    period: "2025 – 2026",
    status: "In Progress",
    statusColor: "#22d3ee",
    note: "Specialization in AI-driven threat intelligence and automated security systems",
  },
  {
    degree: "Bachelor of Computer Application",
    institution: "Seshadripuram College, Tumkur",
    period: "2021 – 2024",
    status: "Completed",
    statusColor: "#a855f7",
    note: null,
  },
  {
    degree: "PCME",
    institution: "Sarvodaya Pre-university College, Tumkur",
    period: "2019 – 2021",
    status: "Completed",
    statusColor: "#a855f7",
    note: null,
  },
];

const certifications = [
  { name: "Cyber Security Professionals (CSP)", issuer: "Industry Certification", highlight: true },
  { name: "Certified Ethical Hacker (CEH)", issuer: "EC-Council", highlight: true },
  { name: "IBM Cybersecurity Foundation", issuer: "IBM", highlight: false },
  { name: "Cybersecurity Certification of Internship", issuer: "Corizo", highlight: false },
  { name: "KSDC SOC Analyst", issuer: "Ashtaksha", highlight: false },
];

const languages = [
  { name: "English", dots: 5 },
  { name: "Hindi", dots: 5 },
  { name: "Kannada", dots: 5 },
];

export default function Education() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="education" ref={ref} data-testid="education-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="mb-14"
      >
        <p className="section-label">&gt; cat credentials.json</p>
        <h2 className="text-4xl md:text-5xl font-extrabold" style={{ fontFamily: "var(--font-display)" }}>
          Education<span className="text-gradient">.</span>
        </h2>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-10">
        <div>
          <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-5">Academic</h3>
          <div className="flex flex-col gap-4">
            {education.map((edu, i) => (
              <motion.div
                key={edu.institution}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                data-testid={`education-${i}`}
                className="relative p-5 rounded-2xl bg-white/2 border border-white/5 hover:border-white/10 transition-all group overflow-hidden"
              >
                {i === 0 && (
                  <div className="absolute top-0 right-0 w-32 h-32 orb-purple rounded-full blur-2xl opacity-60 pointer-events-none" />
                )}
                <div className="flex items-start justify-between gap-3 mb-2 relative z-10">
                  <h4
                    className="font-bold text-foreground text-sm leading-snug"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {edu.degree}
                  </h4>
                  <span
                    className="px-2 py-0.5 rounded-full text-xs font-mono shrink-0"
                    style={{ background: `${edu.statusColor}15`, color: edu.statusColor }}
                  >
                    {edu.status}
                  </span>
                </div>
                <div className="text-sm text-muted-foreground relative z-10">{edu.institution}</div>
                <div className="font-mono text-xs text-muted-foreground/50 mt-1 relative z-10">{edu.period}</div>
                {edu.note && (
                  <div className="mt-3 text-xs text-muted-foreground/60 italic relative z-10">{edu.note}</div>
                )}
              </motion.div>
            ))}
          </div>

          <div className="mt-6">
            <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-4">Languages</h3>
            <div className="flex flex-col gap-3">
              {languages.map((lang, i) => (
                <motion.div
                  key={lang.name}
                  initial={{ opacity: 0 }}
                  animate={inView ? { opacity: 1 } : {}}
                  transition={{ duration: 0.4, delay: 0.5 + i * 0.1 }}
                  data-testid={`language-${lang.name.toLowerCase()}`}
                  className="flex items-center gap-4"
                >
                  <span className="font-mono text-sm text-foreground/70 w-20">{lang.name}</span>
                  <div className="flex gap-1.5 flex-1">
                    {Array.from({ length: 5 }).map((_, j) => (
                      <motion.div
                        key={j}
                        initial={{ scaleX: 0 }}
                        animate={inView ? { scaleX: 1 } : {}}
                        transition={{ duration: 0.3, delay: 0.6 + i * 0.1 + j * 0.05 }}
                        className="flex-1 h-1.5 rounded-full origin-left"
                        style={{
                          background: j < lang.dots
                            ? "linear-gradient(90deg, #a855f7, #22d3ee)"
                            : "rgba(255,255,255,0.07)",
                        }}
                      />
                    ))}
                  </div>
                  <span className="font-mono text-xs text-muted-foreground/50 w-16 text-right">Advanced</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-5">Certifications</h3>
          <div className="flex flex-col gap-3">
            {certifications.map((cert, i) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, x: 20 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.1 + i * 0.08 }}
                data-testid={`cert-${i}`}
                className={`relative p-4 rounded-xl border transition-all group overflow-hidden ${
                  cert.highlight
                    ? "border-primary/20 bg-primary/5"
                    : "border-white/5 bg-white/2 hover:border-white/10"
                }`}
              >
                {cert.highlight && (
                  <div className="absolute top-0 right-0 w-24 h-24 orb-purple rounded-full blur-2xl opacity-40 pointer-events-none" />
                )}
                <div className="relative z-10">
                  <div className="flex items-start justify-between gap-2">
                    <span className={`text-sm font-medium ${cert.highlight ? "text-foreground" : "text-foreground/80"}`}>
                      {cert.name}
                    </span>
                    {cert.highlight && (
                      <span className="px-1.5 py-0.5 rounded text-xs font-mono bg-primary/15 text-primary shrink-0">
                        KEY
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground font-mono mt-1">{cert.issuer}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

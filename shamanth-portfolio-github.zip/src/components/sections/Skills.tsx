import { useRef } from "react";
import { motion, useInView } from "framer-motion";

const coreSkills = [
  { name: "Penetration Testing", level: 90 },
  { name: "SIEM / Threat Hunting", level: 85 },
  { name: "Python / Bash Scripting", level: 80 },
  { name: "Network Security", level: 85 },
  { name: "OSINT & Recon", level: 88 },
  { name: "Malware Analysis", level: 75 },
];

const toolGroups = [
  {
    category: "Exploitation",
    icon: "⚔",
    color: "#a855f7",
    tools: ["Metasploit", "Burp Suite", "Hydra", "John the Ripper", "Hashcat", "Ettercap"],
  },
  {
    category: "Recon & OSINT",
    icon: "🔍",
    color: "#22d3ee",
    tools: ["Nmap", "Maltego", "Shodan", "theHarvester", "Social-Engineer Toolkit"],
  },
  {
    category: "Network & Traffic",
    icon: "📡",
    color: "#a855f7",
    tools: ["Wireshark", "Netcat", "Aircrack-ng", "Snort", "Suricata"],
  },
  {
    category: "Vulnerability Scanning",
    icon: "🛡",
    color: "#22d3ee",
    tools: ["Nessus", "OpenVAS", "Nikto", "Acunetix", "OWASP ZAP"],
  },
  {
    category: "SIEM & Intelligence",
    icon: "📊",
    color: "#a855f7",
    tools: ["Splunk", "Mitre Attack", "QRadar"],
  },
  {
    category: "Platform & Infra",
    icon: "⚙",
    color: "#22d3ee",
    tools: ["Docker", "Kali Linux", "Netcat"],
  },
];

const workshops = [
  { text: "Conducted workshop for PA College of Engineering — 4th semester students", tag: "Speaker" },
  { text: "Attended Ethical Hacking workshop at IISc Bengaluru", tag: "Attendee" },
  { text: "Attended Ethical Hacking workshop at NITK Surathkal", tag: "Attendee" },
];

export default function Skills() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="skills" ref={ref} data-testid="skills-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="mb-14"
      >
        <p className="section-label">&gt; ls -la skills/</p>
        <h2 className="text-4xl md:text-5xl font-extrabold" style={{ fontFamily: "var(--font-display)" }}>
          Skills<span className="text-gradient">.</span>
        </h2>
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-10 mb-14">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.1 }}
        >
          <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-6">
            Proficiency
          </h3>
          <div className="flex flex-col gap-5">
            {coreSkills.map((skill, i) => (
              <div key={skill.name} data-testid={`skill-${skill.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}`}>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-mono text-foreground/80">{skill.name}</span>
                  <span className="text-xs font-mono text-primary/60">{skill.level}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={inView ? { width: `${skill.level}%` } : {}}
                    transition={{ duration: 1, delay: 0.2 + i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                    className="h-full rounded-full"
                    style={{
                      background: `linear-gradient(90deg, #a855f7, #22d3ee)`,
                      boxShadow: "0 0 10px #a855f740",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.15 }}
        >
          <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-6">
            Other Skills
          </h3>
          <div className="flex flex-wrap gap-2">
            {["Cyber Security", "Networking", "Operating System", "Problem-solving", "Communication", "Training", "Presentation", "Wireless Hacking", "Malware Assessment"].map((s) => (
              <span
                key={s}
                className="px-3 py-1.5 rounded-lg font-mono text-xs border border-white/8 text-muted-foreground hover:border-primary/30 hover:text-primary transition-all duration-200 bg-white/2"
              >
                {s}
              </span>
            ))}
          </div>

          <div className="mt-8">
            <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-4">
              Workshops
            </h3>
            <div className="flex flex-col gap-3">
              {workshops.map((w, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 10 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.4, delay: 0.4 + i * 0.1 }}
                  data-testid={`workshop-${i}`}
                  className="flex items-start gap-3 p-3.5 rounded-xl bg-white/2 border border-white/5 hover:border-primary/20 transition-colors"
                >
                  <span
                    className="px-2 py-0.5 rounded text-xs font-mono shrink-0 mt-0.5"
                    style={{ background: "#a855f715", color: "#a855f7" }}
                  >
                    {w.tag}
                  </span>
                  <span className="text-sm text-muted-foreground">{w.text}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7, delay: 0.3 }}
      >
        <h3 className="font-mono text-xs text-muted-foreground tracking-widest uppercase mb-6">
          Tools Arsenal
        </h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {toolGroups.map((group, gi) => (
            <motion.div
              key={group.category}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.35 + gi * 0.07 }}
              data-testid={`tool-group-${group.category.toLowerCase().replace(/\s+/g, "-")}`}
              className="p-5 rounded-2xl bg-white/2 border border-white/5 hover:border-white/10 transition-colors group"
            >
              <div className="flex items-center gap-2 mb-4">
                <span className="text-base">{group.icon}</span>
                <h4
                  className="text-xs font-mono tracking-widest uppercase"
                  style={{ color: group.color }}
                >
                  {group.category}
                </h4>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {group.tools.map((tool) => (
                  <span
                    key={tool}
                    data-testid={`tool-${tool.toLowerCase().replace(/[^a-z0-9]/g, "-")}`}
                    className="px-2.5 py-1 rounded-md text-xs font-mono bg-white/4 text-foreground/70 hover:text-foreground hover:bg-white/8 transition-colors"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}

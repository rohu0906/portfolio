import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Mail, Linkedin, Phone, MapPin, ArrowUpRight, Github } from "lucide-react";

export default function Contact() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="contact" ref={ref} data-testid="contact-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7 }}
        className="mb-14"
      >
        <p className="section-label">&gt; ping shamanth --establish-connection</p>
        <h2 className="text-4xl md:text-5xl font-extrabold" style={{ fontFamily: "var(--font-display)" }}>
          Contact<span className="text-gradient">.</span>
        </h2>
      </motion.div>

      <div className="relative rounded-3xl overflow-hidden border border-white/5 bg-white/2 p-8 md:p-12">
        <div className="absolute top-0 left-0 w-96 h-96 orb-purple rounded-full blur-3xl opacity-30 pointer-events-none -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 orb-cyan rounded-full blur-3xl opacity-20 pointer-events-none translate-x-1/2 translate-y-1/2" />

        <div className="relative z-10 grid md:grid-cols-2 gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            <p className="text-3xl font-extrabold text-foreground mb-3" style={{ fontFamily: "var(--font-display)" }}>
              Let's talk<span className="text-gradient">.</span>
            </p>
            <p className="text-muted-foreground leading-relaxed mb-6 max-w-sm">
              Open to roles in offensive security, red teaming, penetration testing, and AI-powered security automation.
              Response within 24 hours.
            </p>
            <a
              href="mailto:Shamantrsingh@gmail.com"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-mono text-sm font-medium hover:opacity-90 transition-opacity glow-purple"
            >
              <Mail size={15} />
              Send an Email
              <ArrowUpRight size={14} />
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="flex flex-col gap-3"
          >
            {[
              {
                icon: Mail,
                label: "Email",
                value: "Shamantrsingh@gmail.com",
                href: "mailto:Shamantrsingh@gmail.com",
                id: "contact-email",
              },
              {
                icon: Linkedin,
                label: "LinkedIn",
                value: "linkedin.com/in/shamanth-r-2h0c2ooc",
                href: "https://linkedin.com/in/shamanth-r-2h0c2ooc",
                id: "contact-linkedin",
              },
              {
                icon: Phone,
                label: "Phone",
                value: "+91 9620215143",
                href: "tel:+919620215143",
                id: "contact-phone",
              },
              {
                icon: Github,
                label: "GitHub",
                value: "github.com/shamanthwick",
                href: "https://github.com/shamanthwick",
                id: "contact-github",
              },
              {
                icon: MapPin,
                label: "Location",
                value: "Bengaluru, India",
                href: null,
                id: "contact-location",
              },
            ].map((item) => {
              const Inner = (
                <div
                  data-testid={item.id}
                  className={`flex items-center gap-4 p-4 rounded-xl border border-white/5 bg-white/2 transition-all duration-200 group ${
                    item.href ? "hover:border-primary/25 hover:bg-primary/5 cursor-pointer" : ""
                  }`}
                >
                  <div className="w-9 h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                    <item.icon size={16} />
                  </div>
                  <div className="min-w-0">
                    <div className="font-mono text-xs text-muted-foreground/50 mb-0.5">{item.label}</div>
                    <div className="text-sm font-mono text-foreground/80 truncate">{item.value}</div>
                  </div>
                  {item.href && (
                    <ArrowUpRight size={14} className="ml-auto text-muted-foreground/30 group-hover:text-primary transition-colors shrink-0" />
                  )}
                </div>
              );

              return item.href ? (
                <a
                  key={item.label}
                  href={item.href}
                  target={item.href.startsWith("http") ? "_blank" : undefined}
                  rel={item.href.startsWith("http") ? "noopener noreferrer" : undefined}
                >
                  {Inner}
                </a>
              ) : (
                <div key={item.label}>{Inner}</div>
              );
            })}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

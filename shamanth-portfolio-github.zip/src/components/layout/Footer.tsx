export default function Footer() {
  return (
    <footer data-testid="footer" className="border-t border-white/5 py-8 mt-8">
      <div className="max-w-6xl mx-auto px-6 md:px-12 flex flex-col md:flex-row items-center justify-between gap-3">
        <span className="font-mono text-xs text-muted-foreground tracking-widest">
          SHAMANTH.R — CYBERSECURITY PROFESSIONAL
        </span>
        <span className="font-mono text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} — Bengaluru, IN
        </span>
      </div>
    </footer>
  );
}

import { motion, useScroll, useSpring } from "framer-motion";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/sections/Hero";
import About from "@/components/sections/About";
import Experience from "@/components/sections/Experience";
import Skills from "@/components/sections/Skills";
import Education from "@/components/sections/Education";
import Contact from "@/components/sections/Contact";

export default function Home() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <motion.div
        className="fixed top-0 left-0 right-0 h-[2px] origin-left z-[100]"
        style={{
          scaleX,
          background: "linear-gradient(90deg, #a855f7, #22d3ee)",
          boxShadow: "0 0 10px #a855f780",
        }}
      />

      <Navbar />

      <main>
        <Hero />

        <div className="max-w-6xl mx-auto px-6 md:px-12 w-full">
          <div className="space-y-28 py-28">
            <About />
            <Experience />
            <Skills />
            <Education />
            <Contact />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
